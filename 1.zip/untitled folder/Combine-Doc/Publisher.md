## Publisher



Mục tiêu bài viết này giúp ae tìm hiểu sâu hơn về tg ku này nhé. Cách khởi tạo cách sài tất tần tật nhé.

- **Publisher khởi tạo từ giá trị.**

```swift
func example3() {
        let publisher = "I am Ace".publisher
        
        let subscriber = Subscribers.Sink<Character, Never>(receiveCompletion: { completion in
            print(completion)
        }) { value in
            print(value)
        }
        
        publisher.subscribe(subscriber)
        
        subscriber.cancel()
    }
```

Phương thức này giúp ae tạo mọi đối tượng trong swift thành publisher. Và nó sẽ ko bao giờ return nil cả.

Mặc dù chỗ này mình publisher với String nhưng khi bắn ra thì lại là character 

Kết quả in ra: 

```sư
**I**

 

**a**

**m**

 

**A**

**c**

**e**

**finished**
```

Tức là ae có thể hiểu khi đi qua publisher thì đều thành collection cả và không thể có các kiểu như String, Int , Double .. gì đâu nhé.

Ae có thể thử đổi character -> String thì cũng sẽ bị báo lỗi . Khỏi thử =))

`No exact matches in call to instance method 'subscribe' <String, Never>`



- **Publisher khởi tạo từ biến đổi.**

  ```swift
  func example4() {
          let subscriber = Subscribers.Sink<String, Never>(
                              receiveCompletion: {
                                 completion in
                                print(completion)
                            }) { value in
                                print(value)
                           }
          Publishers
                .Sequence<[String], Never>(sequence: ["1", "2", "3", "4"])
                .receive(subscriber: subscriber)
          subscriber.cancel()
      }
  ```

  Cái này đơn giản là khởi tạo từ Publishers với Sequence thôi. 

  

- **Pushlisher từ property của class.**

  1 trường hợp khá hữu ích cho phép ae chuyển đổi giữa UIKIT và Swift UI.

  1 class được viết dạng bt muốn migrate qua combine thì sẽ làm như thế nào ?

  Giả sử mình có 1 class 

  ```swift
  class User {
    @Published var name: String
    @Published var age: Int
    
    init(name: String, age: Int) {
      self.name = name
      self.age = age
    }
  }
  ```

  Muốn "bắn" 1 cục user cho em nào sài thì ae làm như sau. 

  Thêm "@Published" vào trước attribute.

  ```swift
  func example5() {
          let user = User(name: "Fx", age: 29)
  
          let subscriber = user.$name.sink(receiveValue: { (value) in
            print("User name is \(value)")
          })
  
          user.name = "Fx Studio"
          subscriber.cancel()
          
          let subscriber1 = user.$age.sink(receiveValue: { (value) in
            print("User name is \(value)")
          })
  
          user.age = 10
          subscriber1.cancel()
      }
  ```

  Kết quả sẽ là:

  **User name is Fx**

  **User name is Fx Studio**

  **User name is 29**

  **User name is 10**
  
  
  
- **Pushlisher với Just.**
  hiểu nôm na với Just thì khi chúng ta bắn 1 giá trị được tạo sẵn giá trị  thì nhận xong sẽ kết thúc luôn. 

  ```swift
  func example6() {
          let user = Just("abcdef")
  
          let subscriber = user.sink { (value) in
              print(value)
          } receiveValue: { (value1) in
              print(value1)
          }
          subscriber.cancel()
          
          let subscriber2 = user.sink { (value) in
              print(value)
          } receiveValue: { (value1) in
              print(value1)
          }
          subscriber2.cancel()
      }
  ```

  Kết quả sẽ là : 

  abcdef 

  finish 

  abcdef 

  finish

Chỗ này ae chú ý là chúng ta subcriber 2 lần tới just thì nhận dc sẽ finish bình thường. 

- **Future**
  1 khái niệm khá là bác học . Thằng này là 1 publisher là 1 điều chắc chắn rồi. 
  Nó sẽ tựa tựa gần như Just. 
  Khi ae sài nó thì với cứ 1 subcriber tới nó sẽ nhận giá trị success hoặc fail rồi kết thúc.

  Lần đầu thì sẽ thực hiện đầy đủ những gì có trong cái "promise"

  Nhưng những lần sau sẽ lấy ra kết quả cuối cùng thôi.
  Khá khó hiểu đúng ko ae? 
  Mình có thấy 1 ví dụ dưới đây và có viết thêm thắt xíu hi vọng với kết quả in ra ae sẽ thấm xíu.

  ```swift
  func futureIncrement(integer: Int, afterDelay delay: TimeInterval) -> Future<Int, Never> {
          
          Future<Int, Never> { promise in
              print("Original")
              
              Dispatch.DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                  promise(.success(integer + 1))
              }
          
        }
  }
  ```

  ```swift
  func example7() {
          DispatchQueue.main.async {
            // publisher
              let future = self.futureIncrement(integer: 1, afterDelay: 1)
  
  
            // subscription 1
            future
              .sink(receiveCompletion: { print($0) },receiveValue: { print($0) })
              .store(in: &self.subscriptions)
  
            // subscription 2
            future
              .sink(receiveCompletion: { print("Second", $0) },receiveValue: { print("Second", $0) })
              .store(in: &self.subscriptions)
              
              // subscription 3
              future
                .sink(receiveCompletion: { print("Second2", $0) },receiveValue: { print("Second2", $0) })
                .store(in: &self.subscriptions)
          }
      }
  ```

  Kết qủa: 

  ```
  Original
  2
  finished
  Second 2
  Second finished
  Second2 2
  Second2 finished
  ```

  Ae có thể thấy ở lần subcriber đầu tiên mới hiện ra "Original" mà thôi.

  Lần 2 và 3 thì chỉ hiện ra kết quả và finished luôn. 

- **Subjec**t : Món ăn chính đây ae. 
  Tất nhiên anh bạn này cũng là 1 publisher. Nó sẽ linh hoạt hơn ! Nhìn đám cô hồn phía trên cứ nhận là kết thúc ko xin phép ai đúng chán đúng ko :D.

  

  - **PassthroughSubjectRunning**: 

    Loại subject đầu tiên đơn giản ae có thể hiểu là khi khởi tạo nó thì mỗi khi đăng kí sẽ lắng nghe được tất cả các tín hiệu phát ra từ khi đó còn những tín hiệu trước khi đăng kí thì ko được. 
    Có làm thì mới có ăn ko đăng kí thì móm nhé. 
    ko giới hạn ae nào đăng kí tới ! nhiêu thầy cũng nhận dạy hết. 
    Ae có thể xem qua ví dụ dưới.

    ```swift
    func passthroughSubjectRunning() {
            let subject = PassthroughSubject<Int, Never>()
    
            // send value
            subject.send(0)
    
            //subscription 1
            let subscriber1 = subject.sink { (value) in
                print("finished", value)
            } receiveValue: { (value1) in
                print("subscriber1", value1)
            }
    
            // send values
            subject.send(1)
            subject.send(2)
            subject.send(3)
            subject.send(4)
    
    
            //subscription 2
            let subscriber2 = subject.sink { (value) in
                print("finished2", value)
            } receiveValue: { (value1) in
                print("subscriber2", value1)
            }
    
            // send value
            subject.send(5)
            
            // Finished
            subject.send(completion: .finished)
            
            // send value
            subject.send(6)
            
            subscriber1.cancel()
            subscriber2.cancel()
        }
    ```

    Kết quả: 

    ```
    subscriber1 1
    subscriber1 2
    subscriber1 3
    subscriber1 4
    subscriber1 5
    subscriber2 5
    finished finished
    finished2 finished
    ```

    Nhìn vào kết quả so với code trên ae có thể nhận ra rằng : 
    Trước khi thằng 0 bắn ra thì ko ai đăng kí nên ko ai nhận đươc hết. 
    234 thì mình subcriber 1 nhận dc 
    5 thì cả 2 đều nhận dc. 
    thằng 6 thì gửi sau khi finished nên cũng toang luôn . 
    Mình có print "finished" nhưng mãi đến khi cancel 2 ông subcriber mới hiện ra. 

  - **CurrentValueSubject** 

    1 loại subject phổ biến được sử dụng khác với passthough. 
    Loại này sẽ khởi tao với 1 giá trị mặc định. 
    Khi 1 subcriber đăng kí tới nó sẽ bắt đầu nhận tín hiệu và tín hiệu liền kề trước đó. Nên nhớ là chỉ nhận đúng 1 thôi nhé.

    ```swift
    func currentValueSubjectRunning() {
            let subject = CurrentValueSubject<Int, Never>(100)
    
            // send value
            subject.send(0)
    
            //subscription 1
            let subscriber1 = subject.sink { (value) in
                print("finished", value)
            } receiveValue: { (value1) in
                print("subscriber1", value1)
            }
    
            // send values
            subject.send(1)
            subject.send(2)
            subject.send(3)
            subject.send(4)
    
    
            //subscription 2
            let subscriber2 = subject.sink { (value) in
                print("finished2", value)
            } receiveValue: { (value1) in
                print("subscriber2", value1)
            }
    
            // send value
            subject.send(5)
            
            // Finished
            subject.send(completion: .finished)
            
            // send value
            subject.send(6)
            
            subscriber1.cancel()
            subscriber2.cancel()
        }
    ```

    Kết quả: 

    ```
    subscriber1 0
    subscriber1 1
    subscriber1 2
    subscriber1 3
    subscriber1 4
    subscriber2 4
    subscriber2 5
    subscriber1 5
    finished2 finished
    finished finished
    ```

    Khác với thanh niên passthough thì sub1 và 2 nhận thêm dc 1 tín hiệu liền kề là 0 (sub1)và 4 (sub2). 
    Tất nhiên finished rồi thì 2 ae đều đi bụi cả thôi.  

  





