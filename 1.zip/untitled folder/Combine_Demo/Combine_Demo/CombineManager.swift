//
//  CombineManager.swift
//  Combine_Demo
//
//  Created by D.Ace on 9/30/20.
//

import Foundation
import Combine

class CombineManager: NSObject {
    
    private override init() {}
    static let shared = CombineManager()
    
    func example1() {

        let just = Just("Hello world")
        let subscriber = just.sink(receiveCompletion: {
                print("Received completion", $0)
            }, receiveValue: {
                print("Received value", $0)
            })

        subscriber.cancel()
    }
    
    func example2() {
        let publisher = (1...10).publisher

        let subscriber = Subscribers.Sink<Int, Never>(receiveCompletion: { completion in
          print(completion)
        }) { value in
          print(value)
        }

        publisher.map { $0 * 2 }.filter { $0 > 5 }
            .subscribe(subscriber)
        
        subscriber.cancel()
    }
    
    func example3() {
        let publisher = "I am Ace".publisher
        
        let subscriber = Subscribers.Sink<Character, Never>(receiveCompletion: { completion in
            print(completion)
        }) { value in
            print(value)
        }
        
        publisher.subscribe(subscriber)
        
        subscriber.cancel()
    }
    
    func example4() {
        let subscriber = Subscribers.Sink<String, Never>(
                            receiveCompletion: {
                               completion in
                              print(completion)
                          }) { value in
                              print(value)
                         }
        Publishers
              .Sequence<[String], Never>(sequence: ["1", "2", "3", "4"])
              .receive(subscriber: subscriber)
        subscriber.cancel()
        
        
    }
    
    func example5() {
        let user = User(name: "Fx", age: 29)

        let subscriber = user.$name.sink(receiveValue: { (value) in
          print("User name is \(value)")
        })

        user.name = "Fx Studio"
        subscriber.cancel()
        
        let subscriber1 = user.$age.sink(receiveValue: { (value) in
          print("User name is \(value)")
        })

        user.age = 10
        subscriber1.cancel()
    }
    
    func example6() {
        let user = Just("abcdef")

        let subscriber = user.sink { (value) in
            print(value)
        } receiveValue: { (value1) in
            print(value1)
        }
        subscriber.cancel()
        
        let subscriber2 = user.sink { (value) in
            print(value)
        } receiveValue: { (value1) in
            print(value1)
        }
        subscriber2.cancel()
    }
    
    var subscriptions = Set<AnyCancellable>()
    func futureIncrement(integer: Int, afterDelay delay: TimeInterval) -> Future<Int, Never> {
        
        Future<Int, Never> { promise in
            print("Original")
            
            Dispatch.DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                promise(.success(integer + 1))
            }
        
      }
    }
    
    func example7() {
        DispatchQueue.main.async {
          // publisher
            let future = self.futureIncrement(integer: 1, afterDelay: 1)


          // subscription 1
          future
            .sink(receiveCompletion: { print($0) },receiveValue: { print($0) })
            .store(in: &self.subscriptions)

          // subscription 2
          future
            .sink(receiveCompletion: { print("Second", $0) },receiveValue: { print("Second", $0) })
            .store(in: &self.subscriptions)
            
            // subscription 3
            future
              .sink(receiveCompletion: { print("Second2", $0) },receiveValue: { print("Second2", $0) })
              .store(in: &self.subscriptions)
        }
    }
    
    func passthroughSubjectRunning() {
        let subject = PassthroughSubject<Int, Never>()

        // send value
        subject.send(0)

        //subscription 1
        let subscriber1 = subject.sink { (value) in
            print("finished", value)
        } receiveValue: { (value1) in
            print("subscriber1", value1)
        }

        // send values
        subject.send(1)
        subject.send(2)
        subject.send(3)
        subject.send(4)


        //subscription 2
        let subscriber2 = subject.sink { (value) in
            print("finished2", value)
        } receiveValue: { (value1) in
            print("subscriber2", value1)
        }

        // send value
        subject.send(5)
        
        // Finished
        subject.send(completion: .finished)
        
        // send value
        subject.send(6)
        
        subscriber1.cancel()
        subscriber2.cancel()
    }
    
    func currentValueSubjectRunning() {
        let subject = CurrentValueSubject<Int, Never>(100)

        // send value
        subject.send(0)

        //subscription 1
        let subscriber1 = subject.sink { (value) in
            print("finished", value)
        } receiveValue: { (value1) in
            print("subscriber1", value1)
        }

        // send values
        subject.send(1)
        subject.send(2)
        subject.send(3)
        subject.send(4)


        //subscription 2
        let subscriber2 = subject.sink { (value) in
            print("finished2", value)
        } receiveValue: { (value1) in
            print("subscriber2", value1)
        }

        // send value
        subject.send(5)
        
        // Finished
        subject.send(completion: .finished)
        
        // send value
        subject.send(6)
        
        subscriber1.cancel()
        subscriber2.cancel()
    }
    
    func currentValueSubjectRunning2() {
        let subject = AnyPublisher<Any, er>

        // send value
        subject.send(0)

        //subscription 1
        let subscriber1 = subject.sink { (value) in
            print("finished", value)
        } receiveValue: { (value1) in
            print("subscriber1", value1)
        }

        // send values
        subject.send(1)
        subject.send(2)
        subject.send(3)
        subject.send(4)


        //subscription 2
        let subscriber2 = subject.sink { (value) in
            print("finished2", value)
        } receiveValue: { (value1) in
            print("subscriber2", value1)
        }

        // send value
        subject.send(5)
        
        // Finished
        subject.send(completion: .finished)
        
        // send value
        subject.send(6)
        
        subscriber1.cancel()
        subscriber2.cancel()
    }
}

class User {
  @Published var name: String
  @Published var age: Int
  
  init(name: String, age: Int) {
    self.name = name
    self.age = age
  }
}



