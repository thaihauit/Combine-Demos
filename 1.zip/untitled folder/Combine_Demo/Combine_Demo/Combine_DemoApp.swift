//
//  Combine_DemoApp.swift
//  Combine_Demo
//
//  Created by D.Ace on 9/30/20.
//

import SwiftUI

@main
struct Combine_DemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
    
    
}
