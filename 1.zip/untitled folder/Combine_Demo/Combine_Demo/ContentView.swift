//
//  ContentView.swift
//  Combine_Demo
//
//  Created by D.Ace on 9/30/20.
//

import SwiftUI
import Combine

struct ContentView: View {
    var body: some View {
        Text("Hello, world!")
            .padding()
            .onAppear(perform: {
                CombineManager.shared.currentValueSubjectRunning()
                
            })
    }
    
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
