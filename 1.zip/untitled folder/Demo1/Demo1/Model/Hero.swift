//
//  Hero.swift
//  Demo1
//
//  Created by D.Ace on 8/26/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import Foundation
import SwiftUI

let heros = [Hero(id: 1, imageName: "one", name: "captain", info: "awdawdawdawd"),
             Hero(id: 2, imageName: "two", name: "hulk", info: "ggggg"),
             Hero(id: 3, imageName: "three", name: "iron man", info: "akwhdalkwdhlkawd awdawd"),
             Hero(id: 4, imageName: "four", name: "luffy", info: "akwhdal kwdhlkawd"),
             Hero(id: 5, imageName: "five", name: "thor", info: "akwhdalk  wdhlkawd"),
             Hero(id: 6, imageName: "six", name: "loki", info: "akwhd lkwd hlkawd"),]

struct Hero : Identifiable {
    var id: Int
    var imageName: String
    var name: String
    var info : String
}
