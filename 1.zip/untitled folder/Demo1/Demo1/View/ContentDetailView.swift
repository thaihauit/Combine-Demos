//
//  ContentDetailView.swift
//  Demo1
//
//  Created by D.Ace on 8/27/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI

struct ContentDetailView: View {
    
    var hero: Hero
    
    var body: some View {
        Image(hero.imageName)
            .frame(width: 200, height: 200, alignment: .center)
            .padding(.leading, 8)
            .padding(.trailing, 8)
    }
}

struct ContentDetailView_Previews: PreviewProvider {
    static var previews: some View {
        ContentDetailView(hero: Hero(id: 1, imageName: "two", name: "awdawd", info: "awdawd"))
    }
}
