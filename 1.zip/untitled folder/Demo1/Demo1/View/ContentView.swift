//
//  ContentView.swift
//  Demo1
//
//  Created by D.Ace on 8/26/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        VStack {
            NavigationView {
                List (heros) { hero in
                                    
                    NavigationLink(destination: ContentDetailView(hero: hero))
                    {
                        HeroCell(hero: hero)
                    }
                }.navigationBarTitle("HERO", displayMode: .inline)
                
            }
            Button(action: {
                print("awdawdwd")
            }) {
                Text("Input")
                    .fontWeight(.bold)
                    .foregroundColor(Color.green)
                    .padding(.horizontal, 10.0)
                }.padding(.bottom, 10)
        }
    }
    
    func createHero() -> [Hero] {
        return heros
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
