//
//  HeroCell.swift
//  Demo1
//
//  Created by D.Ace on 8/26/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI
import Moya

struct HeroCell: View {
    
    var hero : Hero
    
    var body: some View {
        VStack {
            HStack {
                Image(hero.imageName)
                    .resizable()
                    .frame(width: 60, height: 60)
                    .clipShape(Circle())
                
                VStack(alignment: .leading) {
                    HStack {
                        Text("Name:")
                            .font(.headline)
                        Text(hero.name)
                            .padding(.leading, 8.0)
                    }.padding(.bottom, 8)
                    Text(hero.info).font(.none).multilineTextAlignment(.center)
                }
            }
            
        }
    }
    
    
}

struct HeroCell_Previews: PreviewProvider {
    static var previews: some View {
        HeroCell(hero: Hero(id: 1, imageName: "two", name: "awdawd", info: "awdawd"))
    }
}
