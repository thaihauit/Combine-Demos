//
//  Data.swift
//  Demo2
//
//  Created by D.Ace on 9/9/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import Foundation

let drinks: [Drink] = load("data.json")

func load<T: Decodable> (_ fileName: String, as type: T.Type = T.self) -> T {
    let data: Data
    guard let file = Bundle.main.url(forResource: fileName, withExtension: nil) else {
        fatalError("Loi cmnr")
    }
    
    do {
        data = try Data(contentsOf: file)
    } catch  {
        fatalError("Loi cmnr")
    }
    
    do {
        let decoder = JSONDecoder()
        return try decoder.decode(T.self, from: data)
    } catch  {
        fatalError("Loi cmnr")
    }
}
