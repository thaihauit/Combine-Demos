//
//  Drink.swift
//  Demo2
//
//  Created by D.Ace on 9/9/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import Foundation
import SwiftUI

struct Drink: Hashable, Codable, Identifiable {
    
    var id: Int
    var name: String
    var imageName: String
    var description: String
    var category: Category
    
    enum Category: String, CaseIterable, Codable, Hashable {
        case hot = "hot"
        case cold = "cold"
    }
}
