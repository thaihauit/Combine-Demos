//
//  DrinkItem.swift
//  Demo2
//
//  Created by D.Ace on 9/9/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI

struct DrinkItem: View {
    let item: Drink
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 8) {
            Image(item.imageName)
                .resizable()
                .renderingMode(.original).aspectRatio(contentMode: .fill)
                .frame(width: 300, height: 150, alignment: .center)
                .cornerRadius(8)
                .shadow(radius: 10)
            
            VStack(alignment: .leading, spacing: 8.0) {
                Text(item.imageName)
                    .font(.headline)
                    .fontWeight(.medium)
                    .foregroundColor(Color.black)
                    .lineLimit(2)
                    .padding(.bottom, 4.0)
                
                Text(item.description)
                    .font(.system(size: 13))
                    .fontWeight(.light)
                    .foregroundColor(Color.black)
                .lineLimit(2)
            }
        }
        .padding(.all, 8.0)
    }
}

struct DrinkItem_Previews: PreviewProvider {
    static var previews: some View {
        DrinkItem(item: drinks[0])
    }
}
