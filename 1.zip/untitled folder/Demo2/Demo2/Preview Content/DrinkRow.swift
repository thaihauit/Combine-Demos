//
//  DrinkRow.swift
//  Demo2
//
//  Created by D.Ace on 9/9/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI

struct DrinkRow: View {
    
    var category: String
    var drinks: [Drink]
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 8.0) {
            Text(self.category)
                .font(.title)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(alignment: .top) {
                    ForEach(self.drinks, id: \.name) {
                        drink in
                        NavigationLink(destination: DetailView(drink: drink)) {
                            DrinkItem(item: drink)
                        }
                    }
                    .frame(width: 300)
                    .padding(.trailing, 20)
                }
            }
        }
        .padding(.leading, 8.0)
    }
}

struct DrinkRow_Previews: PreviewProvider {
    static var previews: some View {
        DrinkRow(category: "Cold", drinks: drinks)
    }
}
