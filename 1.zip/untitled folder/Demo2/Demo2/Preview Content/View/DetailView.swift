//
//  DetailView.swift
//  Demo2
//
//  Created by D.Ace on 9/12/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI

struct DetailView: View {
    
    let drink: Drink
    var body: some View {
        List {
            ZStack(alignment: .bottom) {
                Image(drink.imageName)
                    .resizable().aspectRatio(contentMode: .fit)
                
                HStack {
                    VStack(alignment: .leading, spacing: 8.0) {
                        Text(drink.name)
                            .font(.title)
                            .fontWeight(.semibold)
                            .foregroundColor(Color.white)
                        
                    }
                    .padding(.leading)
                    Spacer()
                }
            }
            Text(drink.description)
                .font(.body)
                .fontWeight(.regular)
                .foregroundColor(Color.black)
                .multilineTextAlignment(.leading)
                .lineLimit(10)
            
            HStack(alignment: .bottom) {
                Spacer()
                ExtractedView()
                Spacer()
            }
            .padding()
        }
        
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(drink: drinks[2])
    }
}

struct ExtractedView: View {
    var body: some View {
        Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/) {
            Text("Order Now")
        }.frame(width: 150, height: 40.0)
            .foregroundColor(.white)
            .background(Color.blue)
            .cornerRadius(10)
        
    }
}
