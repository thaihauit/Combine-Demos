//
//  ContentView.swift
//  Demo2
//
//  Created by D.Ace on 9/9/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI

struct HomeView: View {
    
    var categories: [String: [Drink]] {
        .init (
            grouping: drinks,
            by: { $0.category.rawValue }
        )
    }
    
    var body: some View {
        NavigationView {
            List(categories.keys.sorted(), id: \String.self) { (key) in
                
                DrinkRow(category: key, drinks: self.categories[key]!)
            }
            .padding(.vertical)
            .navigationBarTitle(Text("MENU"))
        }
        
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
