//
//  ContentView.swift
//  Demo3
//
//  Created by D.Ace on 9/19/20.
//  Copyright © 2020 D.Ace. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Text("Hello, World!")
            Divider()
            Text("Hello, Worsld!")
        }
        
    }
    
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
