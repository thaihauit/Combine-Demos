//
//  MVVM_SwiftUIApp.swift
//  MVVM-SwiftUI
//
//  Created by D.Ace on 9/29/20.
//

import SwiftUI

@main
struct MVVM_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
