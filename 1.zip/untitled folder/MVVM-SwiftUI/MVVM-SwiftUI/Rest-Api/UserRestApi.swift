//
//  UserRestApi.swift
//  MVVM-SwiftUI
//
//  Created by D.Ace on 9/29/20.
//

import Foundation
import Combine

enum UserRestApi {
    
    private static let base = URL(string: "https://5f7337a7b63868001615f598.mockapi.io/")!
    private static let restApi = RestApi()
    
    static func getUsers() -> AnyPublisher<User, Error> {
        let request = URLComponents(url: base.appendingPathComponent("api/version1/users"), resolvingAgainstBaseURL: true)?
            .request
        return restApi.run(request!)
    }
    
}

private extension URLComponents {
    func addingApiKey(_ apiKey: String) -> URLComponents {
        var copy = self
        copy.queryItems = [URLQueryItem(name: "api_key", value: apiKey)]
        return copy
    }
    
    var request: URLRequest? {
        url.map { URLRequest.init(url: $0) }
    }
}
